export declare const config: {
    tableName: string;
    region: string;
};
