import { GetDataItemGateway } from '../domain/GetDataItemGateway';
import { GetDataItemHandler } from './GetDataItemHandler';
export declare class GetDataItemHandlerConfiguration {
    static getHandler(getDataItemGateway: GetDataItemGateway): GetDataItemHandler;
}
