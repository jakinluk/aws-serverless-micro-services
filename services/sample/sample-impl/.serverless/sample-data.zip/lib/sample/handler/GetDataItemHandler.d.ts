import { APIGatewayProxyEventHandler } from '@lkie/aws-commons';
import { GetDataItemQuery } from '@lkie/sample-api';
import { APIGatewayProxyResult, APIGatewayProxyEvent, Context } from 'aws-lambda';
import { GetDataItemUsecase } from '../domain/GetDataItemUseCase';
export declare class GetDataItemHandler extends APIGatewayProxyEventHandler<GetDataItemQuery, GetDataItemUsecase> {
    constructor(useCase: GetDataItemUsecase);
    process(query: GetDataItemQuery): Promise<APIGatewayProxyResult>;
    extractEvent(input: APIGatewayProxyEvent, context: Context): GetDataItemQuery;
}
