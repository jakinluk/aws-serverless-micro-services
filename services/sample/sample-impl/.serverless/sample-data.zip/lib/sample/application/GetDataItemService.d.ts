import { UseCaseResult } from '@lkie/shared-model';
import { GetDataItemQuery, GetDataItemResponse } from '@lkie/sample-api';
import { GetDataItemGateway } from '../domain/GetDataItemGateway';
import { GetDataItemUseCaseNotFoundError } from '../domain/GetDataItemUseCaseErrors';
import { ItemRepository } from './repository/ItemRepository';
export declare class GetDataItemService implements GetDataItemGateway {
    private readonly repository;
    constructor(repository: ItemRepository);
    getDataItem(query: GetDataItemQuery): Promise<UseCaseResult<GetDataItemResponse, GetDataItemUseCaseNotFoundError>>;
}
