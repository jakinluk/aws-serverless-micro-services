import { ItemRepository } from '../ItemRepository';
import { DocumentClient } from 'aws-sdk/clients/dynamodb';
export declare class DynamoItemRepository implements ItemRepository {
    private readonly documentClient;
    private readonly tableName;
    constructor(documentClient: DocumentClient, tableName: string);
    private static readonly KEY_PREFIX;
    private static readonly SORT_PREFIX;
    getItem(id: string): Promise<{
        [key: string]: unknown;
    }>;
    private buildKey;
    private strip;
}
