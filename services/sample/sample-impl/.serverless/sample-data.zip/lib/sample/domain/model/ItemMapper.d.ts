import { Item } from './Item';
export declare class ItemMapper {
    static toDomain(obj: {
        [key: string]: unknown;
    }): Item;
}
