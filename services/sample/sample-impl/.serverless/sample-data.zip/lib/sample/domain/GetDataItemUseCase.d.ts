import { UseCase, UseCaseResult } from '@lkie/shared-model';
import { GetDataItemQuery, GetDataItemResponse } from '@lkie/sample-api';
import { GetDataItemGateway } from './GetDataItemGateway';
export declare class GetDataItemUsecase implements UseCase<GetDataItemQuery, UseCaseResult<GetDataItemResponse>> {
    private readonly getDataItemGateway;
    constructor(getDataItemGateway: GetDataItemGateway);
    process(query: GetDataItemQuery): Promise<UseCaseResult<GetDataItemResponse>>;
}
