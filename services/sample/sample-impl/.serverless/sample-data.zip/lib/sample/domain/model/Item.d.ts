import { Entity } from '@lkie/shared-model';
export interface ItemProps {
    id: string;
    prop1: string;
    prop2: string;
    createdAt: string;
    updatedAt: string;
}
export declare class Item extends Entity<ItemProps> {
    constructor(props: ItemProps);
    update(newItem: Item): void;
}
