import { UseCaseError } from '@lkie/shared-model';
import { GetDataItemQuery } from '@lkie/sample-api';
export declare class GetDataItemUseCaseNotFoundError extends UseCaseError {
    constructor(query: GetDataItemQuery);
}
export declare class GetDataItemUseCaseUnknownError extends UseCaseError {
    constructor(query: GetDataItemQuery);
}
