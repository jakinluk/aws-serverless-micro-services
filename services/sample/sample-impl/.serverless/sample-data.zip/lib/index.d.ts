import { APIGatewayProxyHandler } from 'aws-lambda/trigger/api-gateway-proxy';
export declare const getDataItemHandler: APIGatewayProxyHandler;
